/**
 * 
 */
/**
 * 
 */
module Sakura {
	requires java.desktop;
}